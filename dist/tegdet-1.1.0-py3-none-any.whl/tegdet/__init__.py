#API
__all__ = ["TEGDetector"]
__version__ = "1.0.1"
__doc__ = "https://github.com/DiasporeUnizar/TEG"