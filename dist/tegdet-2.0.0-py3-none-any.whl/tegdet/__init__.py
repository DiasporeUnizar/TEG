#API
__all__ = ["TEGDetector"]
__version__ = "2.0.0"
__doc__ = "https://github.com/DiasporeUnizar/TEG"